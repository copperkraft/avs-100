function createRegExpForOperand(operandType) {
    var output = '(' + operandType + ')';
    output = output.replace(/r/, 'R[0-9]+');
    output = output.replace(/v/, '[0-9]+');
    output = output.replace(/s/, '".*"');
    return output;
}
function OperationConstructor(name, code, firstOperandType, secondOperandType) {
    var output = '^ *' + name;
    if (firstOperandType) {
        output = output + ' +' + createRegExpForOperand(firstOperandType);
    }
    if (secondOperandType) {
        output = output + ' +' + createRegExpForOperand(secondOperandType);
    }
    output = output + ' *$';
    this.regExpr = new RegExp(output);
    this.operationClosure = function (firstOperand, secondOperand) {
        return function () {
            code.call(this, firstOperand, secondOperand);
        };
    };
}
var functionsArray = [
    new OperationConstructor('MOV', function (to, from) {
        this.registers[to] = Number(this.registers[from] || from);
    }, 'r', 'r|v'),
    new OperationConstructor('ADD', function (to, from) {
        this.registers[to] += Number(this.registers[from]);
    }, 'r', 'r|v'),
    new OperationConstructor('JMP', function (to) {
        this.counter = to - 1;
    }, 'r|v'),
    new OperationConstructor('OUT', function (to) {
        this.output.push(this.registers[to] || to);
    }, 'r|v'),
    new OperationConstructor('SLP', function () {
        this.waiting = !this.waiting;
    })
];
function getOperationByString(input) {
    var string = input.replace(/\/\/.*/, ''),
        i,
        match;
    if (/^ *$/.test(string)) {
        return function () {
            return null;
        };
    }
    for (i = 0; i < functionsArray.length; i++) {
        match = string.match(functionsArray[i].regExpr);
        if (match !== null) {
            return functionsArray[i].operationClosure(match[1], match[2]);
        }
    }
    return 'error';
}

app.factory('functions', function () {
    return {
        getOperationsData: function (input) {
            var arrayLines,
                i,
                funcToSet,
                hasInvalid,
                invalidFunctions = {},
                instructionSet = [];
            arrayLines = input.match(/^.*/gm).map(function (lower) {return lower.toUpperCase(); });
            for (i = 0; i < arrayLines.length; i++) {
                funcToSet = getOperationByString(arrayLines[i]);
                if (funcToSet === 'error') {
                    hasInvalid = true;
                    invalidFunctions[i] = funcToSet;
                }
                instructionSet.push(funcToSet);
            }
            if (hasInvalid) {
                return {
                    invalidFunctions: invalidFunctions,
                    instructionSet: instructionSet
                };
            }
            return {
                instructionSet: instructionSet
            };
        }
    };
});